package com.smallbaazaar.smallbaazaarapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmallbaazaarapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
